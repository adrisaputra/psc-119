<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subdistrict extends Model
{
    use HasFactory;
	protected $fillable =[
        'name'
    ];

    public function village()
    {
        return $this->hasOne('App\Models\Village');
    }

    public function unit()
    {
        return $this->hasOne('App\Models\Unit');
    }


}
