/*
 * Advance Ui MEdia
 */

// Material Box

$(document).ready(function () {
    $('.materialboxed').materialbox();
});