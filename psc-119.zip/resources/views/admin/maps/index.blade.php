@extends('admin.layout')
@section('konten')


<div class="content-wrapper">
	<section class="content-header">
	<h1 class="fontPoppins">{{ __('Google Maps') }}
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> DASHBOARD</a></li>
		<li><a href="#"> {{ __('Google Maps') }}</a></li>
	</ol>
	</section>
	
	<section class="content">
	<div class="row">
        <div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Google Maps</h3>
              <div id="googleMap" style="width:100%;height:500px;"></div>
            </div>
                                    
                                    
          </div>
        </div>


      </div>
	</section>
</div>
<!-- Menyisipkan library Google Maps -->
<script src="http://maps.googleapis.com/maps/api/js?key={{ $setting->gmaps_key }}&callback=initMap"></script>

<script type="text/javascript">

	var map; 
	var lat_longs_map = new Array();
	var markers_map = new Array();
	var iw_map;

	iw_map = new google.maps.InfoWindow();

	function initialize_map() {

	var myLatlng = new google.maps.LatLng(-3.9758718151573267, 122.51756408907299);
	var myOptions = {
		zoom: 11,
		center: myLatlng,
		mapTypeId: google.maps.MapTypeId.hybrid }
	map = new google.maps.Map(document.getElementById("googleMap"), myOptions);
		
	{{-- //@foreach($project as $v)	 --}}
	// Marker 1	
	var myLatlng = new google.maps.LatLng(-3.9758718151573267, 122.51756408907299);

	var pinColor = "#63cbf2";
    var pinLabel = "A";

    // Pick your pin (hole or no hole)
    var pinSVGHole = "M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z";
    var labelOriginHole = new google.maps.Point(12,15);
    var pinSVGFilled = "M 12,2 C 8.1340068,2 5,5.1340068 5,9 c 0,5.25 7,13 7,13 0,0 7,-7.75 7,-13 0,-3.8659932 -3.134007,-7 -7,-7 z";
    var labelOriginFilled =  new google.maps.Point(12,9);


    var markerImage = {  // https://developers.google.com/maps/documentation/javascript/reference/marker#MarkerLabel
        path: pinSVGHole,
        anchor: new google.maps.Point(12,25),
        fillOpacity: 1,
        fillColor: pinColor,
        strokeWeight: 2,
        strokeColor: "white",
        scale: 2,
        labelOrigin: new google.maps.Point(12,30),
    };
	
	var markerOptions = {
		map: map,
		position: myLatlng,
		icon: markerImage
	};
	marker_0 = createMarker_map(markerOptions);

		google.maps.event.addListener(marker_0, "click", function(event) {
         document.getElementById("clickButton").click();
			$.ajax(
            {
               url: "{{ url('/detail_peta/') }}", 
               success: function(result){
				      $("#detail-modal").html(result);
			      }
            })
		});

	{{-- // @endforeach --}}

	}


	function createMarker_map(markerOptions) {
	var marker = new google.maps.Marker(markerOptions);
	markers_map.push(marker);
	lat_longs_map.push(marker.getPosition());
	return marker;
	}

	google.maps.event.addDomListener(window, "load", initialize_map);


</script>
@endsection