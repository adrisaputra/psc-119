@extends('admin.layout')
@section('konten')


<div class="content-wrapper">
	<section class="content-header">
	<h1 class="fontPoppins">{{ __('PDF reader') }}
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> DASHBOARD</a></li>
		<li><a href="#"> {{ __('PDF reader') }}</a></li>
	</ol>
	</section>
	
	<section class="content">
        <div class="box">   
            <div class="box-body">
			 <embed src="{{ asset('') }}/modul_simonik.pdf" type = "application/pdf" width = "100%" height = "700px" />
            </div>
            <div class="box-footer">
                <!-- PAGINATION -->
            </div>
        </div>
	</section>
</div>
@endsection