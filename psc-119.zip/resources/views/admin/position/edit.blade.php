@extends('admin.layout')
@section('konten')
<div class="content-wrapper">
<section class="content-header">
	<h1 class="fontPoppins">{{ __($title) }}
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-dashboard"></i> DASHBOARD</a></li>
		<li><a href="#"> {{ __($title) }}</a></li>
	</ol>
	</section>

	<section class="content">
	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Edit {{ __($title) }}</h3>
		</div>
		
		<form action="{{ url('/'.Request::segment(1).'/edit/'.Crypt::encrypt($position_class_id).'/'.Crypt::encrypt($position->id)) }}" method="POST" enctype="multipart/form-data" class="form-horizontal">
		{{ csrf_field() }}
		<input type="hidden" name="_method" value="PUT">
		
			<div class="box-body">
				<div class="col-lg-12">

					<div class="form-group @if ($errors->has('position_name')) has-error @endif">
						<label class="col-sm-2 control-label">{{ __('Nama Jabatan') }} <span class="required" style="color: #dd4b39;">*</span></label>
						<div class="col-sm-10">
							@if ($errors->has('position_name'))<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> {{ $errors->first('position_name') }}</label>@endif
							<input type="text" class="form-control" placeholder="Nama Jabatan" name="position_name" value="{{ $position->position_name }}" >
						</div>
					</div>
					
					<div class="form-group @if ($errors->has('position_leader')) has-error @endif">
						<label class="col-sm-2 control-label">{{ __('Atasan') }}</label>
						<div class="col-sm-10">
							@if ($errors->has('position_leader'))<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> {{ $errors->first('position_leader') }}</label>@endif
							<select class="form-control select2" name="position_leader">
								<option value=""> -Pilih Atasan-</option>
								@foreach($leader as $v)
									<option value="{{ $v->id }}" @if($position->position_leader==$v->id) selected @endif>{{ $v->position_name }}</option>
								@endforeach
							</select>
						</div>
					</div>

					<div class="form-group @if ($errors->has('office_id')) has-error @endif">
						<label class="col-sm-2 control-label">{{ __('OPD') }}</label>
						<div class="col-sm-10">
							@if ($errors->has('office_id'))<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> {{ $errors->first('office_id') }}</label>@endif
							<select class="form-control select2" name="office_id">
								<option value=""> -Pilih OPD-</option>
								@foreach($office as $v)
									<option value="{{ $v->id }}" @if($position->office_id==$v->id) selected @endif>{{ $v->office_name }}</option>
								@endforeach
							</select>
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-2 control-label"></label>
						<div class="col-sm-10">
							<button type="submit" class="btn btn-primary btn-flat btn-sm" title="Tambah Data"> Simpan</button>
							<button type="reset" class="btn btn-danger btn-flat btn-sm" title="Reset Data"> Reset</button>
							<a href="{{ url('/'.Request::segment(1).'/'.Crypt::encrypt($position_class_id)) }}" class="btn btn-warning btn-flat btn-sm" title="Kembali">Kembali</a>
						</div>
					</div>
					
					
				</div>
			</div>
		</form>
	</div>
	</section>
</div>

@endsection