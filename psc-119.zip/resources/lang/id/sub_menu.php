<?php

return [
    'Grafik' => 'Grafik',
    'Excel' => 'Excel',
    'PDF' => 'PDF',
    'Kelas Jabatan' => 'Kelas Jabatan',
    'OPD' => 'OPD',
    'User' => 'Pengguna',
    'Group' => 'Grup',
    'Menu' => 'Menu',
]; 