<?php

return [
    'dashboard' => 'Dashboard',
    'Rekapitulasi' => 'Rekapitulasi',
    'Data Pegawai' => 'Data Pegawai',
    'Dropzone' => 'Dropzone',
    'Database' => 'Basis Data',
    'PDF Reader' => 'Pembaca PDF',
    'Report' => 'Laporan',
    'Kirim Email' => 'Kirim Email',
    'Maps' => 'Peta',
    'Image Editor' => 'Edit Gambar',
    'Hierarki' => 'Hierarki',
    'Log Activity' => 'Log Aktifitas',
    'Pengaturan' => 'Pengaturan',
]; 