<?php

return [
    'dashboard' => 'Dasbor',
    'total_employee' => 'Jumlah Pegawai',

    'add_data' => 'Tambah Data',
    'update_data' => 'Ubah Data',
    'delete_data' => 'Hapus Data',

    'select_search' => 'Pilih Pencarian',
    'search' => 'Cari',
    'action' => 'Aksi',
]; 