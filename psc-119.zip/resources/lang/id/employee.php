<?php

return [
    'number' => 'No',
    'nip' => 'NIP',
    'barcode' => 'Barcode',
    'name' => 'Nama Pegawai',
    'photo' => 'foto'
]; 