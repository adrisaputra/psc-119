<?php

return [
    'Grafik' => 'Graphic',
    'Excel' => 'Excel',
    'PDF' => 'PDF',
    'Kelas Jabatan' => 'Position Class',
    'OPD' => 'OPD',
    'User' => 'User',
    'Group' => 'Group',
    'Menu' => 'Menu',
]; 