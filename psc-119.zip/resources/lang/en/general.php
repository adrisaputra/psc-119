<?php

return [
    'dashboard' => 'Dashboard',
    'total_employee' => 'Number Of Employee',

    'add_data' => 'Add Data',
    'update_data' => 'Update Data',
    'delete_data' => 'Delete Data',

    'select_search' => 'Select Search',
    'search' => 'Search',
    'action' => 'Action',
]; 