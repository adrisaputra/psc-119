<?php

return [
    'number' => 'No',
    'nip' => 'NIP',
    'barcode' => 'Barcode',
    'name' => 'Employee Name',
    'photo' => 'Photo',
]; 