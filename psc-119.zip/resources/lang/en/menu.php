<?php

return [
    'dashboard' => 'Dashboard',
    'Rekapitulasi' => 'Recapitulation',
    'Data Pegawai' => 'Employee Data',
    'Dropzone' => 'Dropzone',
    'Database' => 'Database',
    'PDF Reader' => 'PDF Reader',
    'Report' => 'Report',
    'Kirim Email' => 'Send Email',
    'Maps' => 'Maps',
    'Image Editor' => 'Image Editor',
    'Hierarki' => 'Hierarki',
    'Log Activity' => 'Log Activity',
    'Pengaturan' => 'Setting',
]; 